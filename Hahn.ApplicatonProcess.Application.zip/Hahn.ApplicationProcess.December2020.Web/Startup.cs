using System;
using System.IO;
using System.Reflection;
using Aurelia.DotNet;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Type;
using Hahn.ApplicatonProcess.December2020.Web;
using Hahn.ApplicationProcess.December2020.Web.Common.Swagger;

namespace Hahn.ApplicationProcess.December2020.Web
{
    /// <summary>
    /// Startup class.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <value>
        /// The configuration.
        /// </value>
        public IConfiguration Configuration { get; }


        /// <summary>
        /// Configures the services. This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<DataContext>(context => context.UseInMemoryDatabase("InMemory"));
            services.AddControllers();
            services.AddMvc().AddNewtonsoftJson();

            services.AddMvcCore().SetCompatibilityVersion(CompatibilityVersion.Latest);
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "ClientApp/dist";
            });
            DependencyInjection.Configuration(services);
            services.AddSwaggerExamplesFromAssemblyOf<Applicant>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
                c.ExampleFilters();


                //c.OperationFilter<AddHeaderOperationFilter>("correlationId", "Correlation Id for the request", false); 
                c.OperationFilter<AddResponseHeadersFilter>();

                var filePath = Path.Combine(AppContext.BaseDirectory, "Hahn.ApplicatonProcess.December2020.Web.xml");
                c.IncludeXmlComments(filePath, true);

                var filePathType = Path.Combine(AppContext.BaseDirectory, "Hahn.ApplicatonProcess.December2020.Type.xml");
                c.IncludeXmlComments(filePathType);                
            });

            services.AddSwaggerExamplesFromAssemblies(Assembly.GetEntryAssembly());

        }

        /// <summary>
        /// Configures the specified application.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The env.</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors("hahnPolicy");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Hahn API V1");
            });

            app.UseSpa(spa =>
            {
                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment())
                {
                    spa.UseAureliaCliServer();
                }
            });
        }
    }
}