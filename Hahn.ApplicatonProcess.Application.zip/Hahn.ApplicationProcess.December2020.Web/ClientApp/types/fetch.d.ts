declare module "isomorphic-fetch" {
  export = fetch;
}
