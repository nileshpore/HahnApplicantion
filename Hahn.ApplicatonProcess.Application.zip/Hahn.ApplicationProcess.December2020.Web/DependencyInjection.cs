﻿using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Data.Implementation;
using Hahn.ApplicatonProcess.December2020.Domain.Contract;
using Hahn.ApplicatonProcess.December2020.Domain.Implementation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.December2020.Web
{
    /// <summary>
    /// DependencyInjection
    /// </summary>
    public class DependencyInjection
    {
        /// <summary>
        /// Configurations the specified services.
        /// </summary>
        /// <param name="services">The services.</param>
        public static void Configuration(IServiceCollection services)
        {
            services.AddDbContext<DataContext>(opt => opt.UseInMemoryDatabase("DataContext"));
            services.AddScoped<DataContext, DataContext>();

            services.AddTransient<IApplicantService, ApplicantService>();
            services.AddTransient<IApplicantRepository, ApplicantRepository>();

        }
    }
}
