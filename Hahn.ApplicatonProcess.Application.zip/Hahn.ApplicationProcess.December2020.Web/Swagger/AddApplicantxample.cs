using Hahn.ApplicatonProcess.December2020.Type;
using Hahn.ApplicatonProcess.December2020.Type.Dto;
using Swashbuckle.AspNetCore.Filters;
using System;

namespace Hahn.ApplicationProcess.December2020.Web.Common.Swagger
{

    /// <summary>
    /// Applicant Request Example
    /// </summary>
    public class AddApplicantExample_Request : IExamplesProvider<Applicant>
    {
        /// <summary>
        /// Get Application example
        /// </summary>
        /// <returns></returns>
        public Applicant GetExamples()
        {
            return new Applicant()
            {
                Address = $"Sample address - This is really big address {new Random(1).Next(9999999)}",
                Age = new Random(20).Next(20, 60),
                CountryOfOrigin = "Germany",
                Email = $"Hahnser{new Random(1).Next(9999999)}@gmail.com",
                FamilyName = $"Hahn User - {new Random(1).Next(9999999)}",
                Hired = true,
                Name = "Nilesh",
                Id = new Random(1).Next(9999999)
            };
        }
    }

    /// <summary>
    /// Applicant Response Example
    /// </summary>
    public class AddApplicantExample_Response : IExamplesProvider<Response<ApplicantResponse>>
    {
        /// <summary>
        /// Get Application example
        /// </summary>
        /// <returns></returns>
        public Response<ApplicantResponse> GetExamples()
        {
            return new Response<ApplicantResponse>()
            {
                IsValid = true,
                Data = new ApplicantResponse()
                {
                    Applicants = new System.Collections.Generic.List<Applicant>(),
                    ValidationMessage = new System.Collections.Generic.List<string>()
                }

            };
        }
    }
}