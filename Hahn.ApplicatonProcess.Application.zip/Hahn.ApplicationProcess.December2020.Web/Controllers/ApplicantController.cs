using System;
using System.Net;
using System.Threading.Tasks;
using Hahn.ApplicationProcess.December2020.Web.Common.Swagger;
using Hahn.ApplicatonProcess.December2020.Domain.Contract;
using Hahn.ApplicatonProcess.December2020.Type;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicationProcess.December2020.Web.Controllers
{
    

    /// <summary>
    /// Applicant CRUD operation controller.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantService applicantService;
        private readonly ILogger logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicantController" /> class.
        /// </summary>
        /// <param name="applicantService">The applicant service.</param>
        /// <param name="logger">The logger.</param>
        public ApplicantController(IApplicantService applicantService, ILogger<ApplicantController> logger)
        {
            this.applicantService = applicantService;
            this.logger = logger;
        }

        /// <summary>
        /// [Add new applicant] This Api is used to add new applicant into the system.
        /// </summary>
        /// <param name="applicant">This parameter should not  be null. Required.</param>
        /// <returns></returns>
        /// <example>This is examplel</example>
        [HttpPost]
        [Produces("application/json")]
        [Consumes("application/json")]
        [SwaggerResponse((int)HttpStatusCode.Created, "Add Applicant", typeof(AddApplicantExample_Request))]
        [SwaggerRequestExample(typeof(Applicant), typeof(AddApplicantExample_Request))]
        [SwaggerResponseExample((int)HttpStatusCode.Created, typeof(AddApplicantExample_Response))]
        [SwaggerOperation(Summary = "Creates a new applicant", Description = "Requires applicant information should be valid for all fields", OperationId = "AddApplicant", Tags = new[] { "Applicant" })]
        public async Task<ActionResult> AddApplicant([FromBody] Applicant applicant)
        {
            try
            {
                var response = await applicantService.AddApplicant(applicant);
                if (response.IsValid)
                    return StatusCode((int)HttpStatusCode.Created, response);
                else
                    return StatusCode((int)HttpStatusCode.BadRequest, response);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return BadRequest(e.Message);
            }
        }


        /// <summary>
        /// [Get all applicant] This Api will return all the applicant in the system.
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        [Produces("application/json")]
        [Consumes("application/json")]
        public async Task<ActionResult> GetAllApplicant()
        {
            try
            {
                var result = await applicantService.GetAllApplicant();
                return new JsonResult(result);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return BadRequest(e.Message);
            }
           
        }

        /// <summary>
        /// Gets the applicant by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [Produces("application/json")]
        [Consumes("application/json")]
        public async Task<ActionResult> GetApplicantById(int id)
        {
            try
            {
                var result = await applicantService.GetApplicantById(id);
                return new JsonResult(result);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return BadRequest(e.Message);
            }
            
        }


        /// <summary>
        /// Updataes the applicant by identifier.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [Produces("application/json")]
        [Consumes("application/json")]
        public async Task<ActionResult> UpdataeApplicant( [FromBody] Applicant applicant)
        {
        
            try
            {
                var result = await applicantService.UpdataeApplicant(applicant);
                return new OkResult();
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Deletes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [Produces("application/json")]
        [Consumes("application/json")]
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                var result = await applicantService.DeleteApplicant(id);
                return new OkResult();
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return BadRequest(e.ToString());
            }            
        }
    }
}