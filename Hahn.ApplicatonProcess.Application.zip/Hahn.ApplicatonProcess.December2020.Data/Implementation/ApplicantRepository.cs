﻿using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Type;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Implementation
{
    /// <summary>
    /// ApplicantRepository
    /// </summary>
    /// <seealso cref="Hahn.ApplicatonProcess.December2020.Data.Contract.IApplicantRepository" />
    public class ApplicantRepository : IApplicantRepository
    {
        private readonly DataContext context;
        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicantRepository"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public ApplicantRepository(DataContext context)
        {
            this.context = context;
        }
        /// <summary>
        /// Adds the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        /// <exception cref="ApplicationException">ApplicantRepository.AddApplicant: Applicant object can not be null</exception>
        public async Task<int> AddApplicant(Applicant applicant)
        {
            if (applicant == null)
            {
                throw new ApplicationException("ApplicantRepository.AddApplicant: Applicant object can not be null");
            }
            context.Applicant.Add(applicant);
            await context.SaveChangesAsync();
            return applicant.Id;
        }

        /// <summary>
        /// Deletes the applicant.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<bool> DeleteApplicant(int id)
        {
            var applicant = context.Applicant.Where(t => t.Id == id).SingleOrDefault();
            if (applicant != null)
            {
                await Task.Run(() => { context.Applicant.Remove(applicant); });
            }
            return true;
        }

        /// <summary>
        /// Gets all applicant.
        /// </summary>
        /// <returns></returns>
        public async Task<List<Applicant>> GetAllApplicant()
        {
            return await Task.Run(() => context.Applicant.ToList());
        }

        /// <summary>
        /// Gets the applicant by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public async Task<Applicant> GetApplicantById(int id)
        {
            return await Task.Run(() => context.Applicant.Where(t => t.Id == id).SingleOrDefault());
        }

        /// <summary>
        /// Updataes the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<bool> UpdataeApplicant(Applicant applicant)
        {
            var dbApplicant = context.Applicant.SingleOrDefault(t => t.Id == applicant.Id);
            if (dbApplicant != null)
            {

                dbApplicant.Address = applicant.Address;
                dbApplicant.Age = applicant.Age;
                dbApplicant.CountryOfOrigin = applicant.CountryOfOrigin;
                dbApplicant.Email = applicant.Email;
                dbApplicant.FamilyName = applicant.FamilyName;
                dbApplicant.Hired = applicant.Hired;
                dbApplicant.Name = applicant.Name;
                await context.SaveChangesAsync();
            }
            return true;
        }
    }
}
