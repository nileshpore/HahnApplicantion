﻿using Hahn.ApplicatonProcess.December2020.Type;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Contract
{
    /// <summary>
    /// IApplicantRepository
    /// </summary>
    public interface IApplicantRepository
    {
        /// <summary>
        /// Adds the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        Task<int> AddApplicant(Applicant applicant);
        /// <summary>
        /// Gets all applicant.
        /// </summary>
        /// <returns></returns>
        Task<List<Applicant>> GetAllApplicant();

        /// <summary>
        /// Gets the applicant by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        Task<Applicant> GetApplicantById(int id);

        /// <summary>
        /// Updataes the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        Task<bool> UpdataeApplicant(Applicant applicant);

        /// <summary>
        /// Deletes the applicant.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        Task<bool> DeleteApplicant(int id);
    }
}
