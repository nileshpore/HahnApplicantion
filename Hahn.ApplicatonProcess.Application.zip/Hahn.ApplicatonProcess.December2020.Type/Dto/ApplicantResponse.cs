﻿using System.Collections.Generic;

namespace Hahn.ApplicatonProcess.December2020.Type.Dto
{
    /// <summary>
    /// 
    /// </summary>
    public class ApplicantResponse
    {
        /// <summary>Initializes a new instance of the <see cref="ApplicantResponse" /> class.</summary>
        public ApplicantResponse()
        {
            ValidationMessage = new List<string>();
            Applicants = new List<Applicant>();
        }
        /// <summary>Gets or sets the validation message.</summary>
        /// <value>The validation message.</value>
        public List<string> ValidationMessage { get; set; }
        /// <summary>Gets or sets the applicants.</summary>
        /// <value>The applicants.</value>
        public List<Applicant> Applicants { get; set; }
    }
}
