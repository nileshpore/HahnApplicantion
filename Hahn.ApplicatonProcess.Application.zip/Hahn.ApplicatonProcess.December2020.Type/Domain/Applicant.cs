﻿namespace Hahn.ApplicatonProcess.December2020.Type
{
    /// <summary>
    /// Applicant  Domain Class.
    /// </summary>
    public class Applicant
    {
        /// <summary>
        /// Id : Accept numbers. Required.
        /// </summary>
        ///<example>1</example>
        public int Id { get; set; }


        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets the name of the family.
        /// </summary>
        /// <value>
        /// The name of the family.
        /// </value>
        public string FamilyName { get; set; }
        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address { get; set; }
        /// <summary>
        /// Gets or sets the country of origin.
        /// </summary>
        /// <value>
        /// The country of origin.
        /// </value>
        public string CountryOfOrigin { get; set; }
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        public string Email { get; set; }
        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>
        /// The age.
        /// </value>
        public int Age { get; set; }
        /// <summary>
        /// Gets or sets the hired.
        /// </summary>
        /// <value>
        /// The hired.
        /// </value>
        public bool? Hired { get; set; }
    }
}
