using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Domain.Implementation;
using Hahn.ApplicatonProcess.December2020.Type;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using FluentAssert;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Test
{
    [TestClass]
    public class ApplicantServiceTest
    {
        [TestMethod]
        public void AddApplicant_ValidateFirstName_InValidFirstName_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Name should have at least 5 characters.";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.Name = "abcd";
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }

        [TestMethod]
        public void AddApplicant_ValidateFamilyName_InValidFamilyName_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Family Name should have at least 10 characters.";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.FamilyName = "abcd";
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }

        [TestMethod]
        public void AddApplicant_ValidateEmail_InValidEmail_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Email address is not in correct format.";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.Email = "abcd";
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }

        [TestMethod]
        public void AddApplicant_ValidateAge_InValidAge_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Age should be between 20 and 60";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.Age = 15;
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }

        [TestMethod]
        public void AddApplicant_ValidateHired_InValidHiredFlag_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Hired field shold not be null";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.Hired = null;
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }

        [TestMethod]
        public void AddApplicant_ValidateCountry_InValidCountry_ShouldReturnValidationError()
        {
            //Arrange
            var expectedMessage = "Country name is invalid";
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();
            applicant.CountryOfOrigin = "abc";
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeFalse();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(1);
            result.Data.ValidationMessage.Contains(expectedMessage);
        }


        [TestMethod]
        public void AddApplicant_ValidInput_ShouldNotReturnValidationError()
        {
            //Arrange            
            var mock = new Mock<IApplicantRepository>();
            var applicant = GetApplicant();            
            mock.Setup(p => p.AddApplicant(applicant)).Returns(Task.FromResult(1));


            //Act
            ApplicantService applicantService = new ApplicantService(mock.Object);
            var result = applicantService.AddApplicant(applicant).Result;

            //Assert
            result.IsValid.ShouldBeTrue();
            result.Data.ValidationMessage.ShouldNotBeNull();
            result.Data.ValidationMessage.Count.ShouldBeEqualTo(0);
        }

        private Applicant GetApplicant()
        {
            return new Applicant()
            {
                Id = 1,
                Age = 33,
                Address = "Street: Ollenhauer Str. 48. City: Stuttgart Neugereut. State/province/area: Baden-W�rttemberg. Phone number 0711 63 88 01. Zip code 70378",
                CountryOfOrigin = "india",
                Email = "emerson@haan.com",
                FamilyName = "Abel Emerson",
                Hired = true,
                Name = "Emerson Abel"
            };
        }
    }
}
