﻿using Hahn.ApplicatonProcess.December2020.Type;
using Hahn.ApplicatonProcess.December2020.Type.Dto;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Contract
{
    /// <summary>
    /// IApplicantService
    /// </summary>
    public interface IApplicantService
    {
        /// <summary>
        /// Adds the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        Task<Response<ApplicantResponse>> AddApplicant(Applicant applicant);
        /// <summary>
        /// Gets all applicant.
        /// </summary>
        /// <returns></returns>
        Task<Response<ApplicantResponse>> GetAllApplicant();

        /// <summary>
        /// Gets the applicant by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        Task<Applicant> GetApplicantById(int id);

        /// <summary>
        /// Updataes the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        Task<bool> UpdataeApplicant(Applicant applicant);

        /// <summary>
        /// Deletes the applicant.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        Task<bool> DeleteApplicant(int id);
    }
}
