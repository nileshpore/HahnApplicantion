﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Domain.ValidationRules;
using Hahn.ApplicatonProcess.December2020.Type;

namespace Hahn.ApplicatonProcess.December2020.Domain.Validation
{
    /// <summary>
    /// ApplicantValidation
    /// </summary>
    /// <seealso ref="FluentValidation.AbstractValidator{Hahn.ApplicatonProcess.December2020.Type.Applicant}" />
    public class ApplicantValidation : AbstractValidator<Applicant>
    {
        private const int NameMinimumLength = 5;
        private const int FamilyNameMinumumLength = 10;
        private const int AgeMin = 20;
        private const int AgeMax = 60;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicantValidation"/> class.
        /// </summary>
        public ApplicantValidation()
        {
            RuleFor(x => x.Name).MinimumLength(NameMinimumLength).WithMessage($"Name should have at least {NameMinimumLength} characters.");
            RuleFor(x => x.FamilyName).MinimumLength(FamilyNameMinumumLength).WithMessage($"Family Name should have at least {FamilyNameMinumumLength} characters.");
            RuleFor(x => x.Email).EmailAddress().WithMessage("Email address is not in correct format");
            RuleFor(x => x.Age).InclusiveBetween(AgeMin, AgeMax).WithMessage($"Age should be between {AgeMin} and {AgeMax}");
            RuleFor(x => x.Hired).NotNull().WithMessage("Hired field shold not be null");
            RuleFor(x => x.CountryOfOrigin).Must(x => CountryNameValidator.CheckCountrNameExists(x).Result).WithMessage("Country name is invalid");
        }
    }
}
