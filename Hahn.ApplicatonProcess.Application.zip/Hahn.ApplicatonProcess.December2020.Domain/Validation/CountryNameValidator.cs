﻿using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.ValidationRules
{
    /// <summary>
    /// CountryNameValidator
    /// </summary>
    public static  class CountryNameValidator
    {
        private static HttpClient client = new HttpClient();
        private const string findCountryUrl = "https://restcountries.eu/rest/v2/name/{0}?fullText=true";


        /// <summary>
        /// Checks the countr name exists.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public static async Task<bool> CheckCountrNameExists(string name)
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync(string.Format(findCountryUrl, name));
                response.EnsureSuccessStatusCode();                
                return response.StatusCode == System.Net.HttpStatusCode.OK;
            }
            catch
            {
                return false;
            }
        }
    }
}
