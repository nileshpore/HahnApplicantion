﻿using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Domain.Contract;
using Hahn.ApplicatonProcess.December2020.Domain.Validation;
using Hahn.ApplicatonProcess.December2020.Type;
using Hahn.ApplicatonProcess.December2020.Type.Dto;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Implementation
{
    /// <summary>
    /// ApplicantService
    /// </summary>
    /// <seealso cref="Hahn.ApplicatonProcess.December2020.Domain.Contract.IApplicantService" />
    public class ApplicantService : IApplicantService
    {
        private readonly IApplicantRepository applicantRepository;
        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicantService"/> class.
        /// </summary>
        /// <param name="applicantRepository">The applicant repository.</param>
        public ApplicantService(IApplicantRepository applicantRepository)
        {
            this.applicantRepository = applicantRepository;
        }
        /// <summary>
        /// Add applicant service. To add applicant into in memomry database.
        /// </summary>
        /// <param name="applicant">Applicant object</param>
        /// <returns></returns>
        public async Task<Response<ApplicantResponse>> AddApplicant(Applicant applicant)
        {
            Response<ApplicantResponse> response = new Response<ApplicantResponse>() { Data = new ApplicantResponse() };
            applicant.Name = applicant.Name ?? string.Empty;
            applicant.FamilyName = applicant.FamilyName ?? string.Empty;
            applicant.CountryOfOrigin = applicant.CountryOfOrigin ?? string.Empty;

            var validationResult = await new ApplicantValidation().ValidateAsync(applicant);

            if (validationResult.IsValid)
            {
                await applicantRepository.AddApplicant(applicant);
                response.IsValid = true;
            }
            else
            {
                response.Data.ValidationMessage = validationResult.Errors.Select(t => t.ErrorMessage).ToList();
                response.IsValid = false;
            }
            return response;
        }

        /// <summary>
        /// Deletes the applicant.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public async Task<bool> DeleteApplicant(int id)
        {
            return await applicantRepository.DeleteApplicant(id);
        }

        /// <summary>
        /// Ge all applicant from the system.
        /// </summary>
        /// <returns></returns>
        public async Task<Response<ApplicantResponse>> GetAllApplicant()
        {
            Response<ApplicantResponse> response = new Response<ApplicantResponse>() { Data = new ApplicantResponse(), IsValid = true };
            response.Data.Applicants = await applicantRepository.GetAllApplicant();
            return response;
        }

        /// <summary>
        /// Gets the applicant by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public async Task<Applicant> GetApplicantById(int id)
        {
            return await applicantRepository.GetApplicantById(id);
        }

        /// <summary>
        /// Updataes the applicant.
        /// </summary>
        /// <param name="applicant">The applicant.</param>
        /// <returns></returns>
        public async Task<bool> UpdataeApplicant(Applicant applicant)
        {
            return await applicantRepository.UpdataeApplicant(applicant);
        }
    }
}
