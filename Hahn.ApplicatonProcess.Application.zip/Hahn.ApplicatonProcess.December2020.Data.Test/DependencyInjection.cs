﻿using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Data.Implementation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.December2020.Data.Test
{
    public class DependencyInjection
    {
        public static void Configuration(IServiceCollection services)
        {
            services.AddDbContext<DataContext>(opt => opt.UseInMemoryDatabase("DataContext"));
            services.AddScoped<DataContext, DataContext>();
            
            services.AddTransient<IApplicantRepository, ApplicantRepository>();
        }
    }
}
