using Hahn.ApplicatonProcess.December2020.Data.Contract;
using Hahn.ApplicatonProcess.December2020.Type;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using FluentAssert;

namespace Hahn.ApplicatonProcess.December2020.Data.Test
{
    [TestClass]
    public class ApplicantRepositoryTest
    {
        private ServiceProvider serviceProvider { get; set; }

        [TestInitialize]
        public  void Initialize()
        {
            var services = new ServiceCollection();
            DependencyInjection.Configuration(services);
            serviceProvider = services.BuildServiceProvider();
        }
        [TestMethod]
        public void AddApplicant_CorrectDataPassed_ShouldAddApplicant()
        {
            //Arrange
            var applicantRepository = serviceProvider.GetService<IApplicantRepository>();
            var applicant = GetApplicant();

            //Act
            var result = applicantRepository.AddApplicant(applicant);

            //Assert            
            result.Id.ShouldNotBeEqualTo(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void AddApplicant_NullData_ShouldThrowException()
        {
            //Arrange
            var applicantRepository = serviceProvider.GetService<IApplicantRepository>();
            Applicant applicant = null;

            //Act
            var result = applicantRepository.AddApplicant(applicant);

            //Assert
            //Should throw  exception
        }

        [TestMethod]        
        public void AddApplicant_CorrectData_VerifyDataIsAdded()
        {
            //Arrange
            var applicantRepository = serviceProvider.GetService<IApplicantRepository>();
            var dataContext = serviceProvider.GetService<DataContext>();
            ClearApplicant(dataContext);
            Applicant applicant = GetApplicant();
           

            //Act
            var result = applicantRepository.AddApplicant(applicant);

            //Assert
            var applicantCount = dataContext.Applicant.Count();
            var insertedRecord = dataContext.Applicant.First();
            
            result.Id.ShouldNotBeEqualTo(0);
            applicantCount.ShouldBeEqualTo(1);
            insertedRecord.ShouldNotBeNull();
            insertedRecord.Id.ShouldBeEqualTo(applicant.Id);
            insertedRecord.Address.ShouldBeEqualTo(applicant.Address);
            insertedRecord.Age.ShouldBeEqualTo(applicant.Age);
            insertedRecord.CountryOfOrigin.ShouldBeEqualTo(applicant.CountryOfOrigin);
            insertedRecord.Email.ShouldBeEqualTo(applicant.Email);
            insertedRecord.FamilyName.ShouldBeEqualTo(applicant.FamilyName);
            insertedRecord.Hired.ShouldBeEqualTo(applicant.Hired);
            insertedRecord.Name.ShouldBeEqualTo(applicant.Name);
        }

        [TestMethod]
        public void GetAllApplicant_ShouldReturn_AllApplicants()
        {
            //Arrange
            var applicantRepository = serviceProvider.GetService<IApplicantRepository>();
            var dataContext = serviceProvider.GetService<DataContext>();
            ClearApplicant(dataContext);
            Applicant applicant = GetApplicant();

            applicantRepository.AddApplicant(applicant);
            applicant.Id = 2;
            applicantRepository.AddApplicant(applicant);

            //Act
            var result = applicantRepository.GetAllApplicant().Result;

            //Assert
            result.Count.ShouldBeEqualTo(2);               
        }
        private Applicant GetApplicant()
        {
            return new Applicant()
            {
                Id = 1,
                Age = 33,
                Address = "Street: Ollenhauer Str. 48. City: Stuttgart Neugereut. State/province/area: Baden-W�rttemberg. Phone number 0711 63 88 01. Zip code 70378",
                CountryOfOrigin = "India",
                Email = "emerson@haan.com",
                FamilyName = "Abel",
                Hired = true,
                Name = "Emerson Abel"
            };
        }


        private void ClearApplicant(DataContext context)
        {
            context.Applicant.RemoveRange(context.Applicant.ToList());
            context.SaveChanges();
        }
    }
}
